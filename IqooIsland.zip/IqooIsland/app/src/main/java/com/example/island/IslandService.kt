package com.example.island

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.*
import android.text.TextUtils
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var pill: LinearLayout
    private lateinit var title: TextView
    private lateinit var body: TextView
    private lateinit var musicLabel: TextView
    private lateinit var controls: LinearLayout
    private lateinit var playBtn: Button
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private val collapseRunnable = Runnable { setExpanded(false) }
    private var expanded = false
    private var media: MediaController? = null
    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(m: MediaMetadata?) = refreshMedia()
        override fun onPlaybackStateChanged(s: PlaybackState?) = refreshMedia()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val ch = "island"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Island", NotificationManager.IMPORTANCE_MIN))
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Island running").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        buildIsland()
        setMedia(pendingMedia)
    }

    private fun txt(color: Long, size: Float) = TextView(this).apply {
        setTextColor(color.toInt()); textSize = size; visibility = View.GONE
    }

    private fun ctl(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(0xFFFFFFFF.toInt()); textSize = 18f
        setBackgroundColor(0); setOnClickListener { action(); handler.removeCallbacks(collapseRunnable); handler.postDelayed(collapseRunnable, 4000) }
    }

    private fun buildIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        title = txt(0xFFFFFFFF, 14f)
        body = txt(0xFFBBBBBB, 12f)
        musicLabel = txt(0xFFFFFFFF, 11f).apply { isSingleLine = true; ellipsize = TextUtils.TruncateAt.END }
        playBtn = ctl("▶") {
            val t = media?.transportControls ?: return@ctl
            if (media?.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
        }
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE
            addView(ctl("⏮") { media?.transportControls?.skipToPrevious() })
            addView(playBtn)
            addView(ctl("⏭") { media?.transportControls?.skipToNext() })
        }
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.island_bg)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            addView(title); addView(body); addView(musicLabel); addView(controls)
            setOnClickListener {
                if (!expanded && musicLabel.visibility != View.VISIBLE) return@setOnClickListener
                setExpanded(!expanded)
            }
        }
        lp = WindowManager.LayoutParams(
            dp(120), dp(34),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
        wm.addView(pill, lp)
    }

    private fun applyState() {
        val hasMedia = musicLabel.visibility == View.VISIBLE
        title.visibility = if (expanded && title.text.isNotEmpty()) View.VISIBLE else View.GONE
        body.visibility = if (expanded && body.text.isNotEmpty()) View.VISIBLE else View.GONE
        controls.visibility = if (expanded && hasMedia) View.VISIBLE else View.GONE
        lp.width = dp(if (expanded) 340 else if (hasMedia) 170 else 120)
        lp.height = if (expanded) WindowManager.LayoutParams.WRAP_CONTENT else dp(34)
        wm.updateViewLayout(pill, lp)
    }

    private fun setExpanded(on: Boolean) {
        handler.removeCallbacks(collapseRunnable)
        expanded = on
        if (!on) { title.text = ""; body.text = "" }
        applyState()
        if (on) handler.postDelayed(collapseRunnable, 4000)
    }

    private fun refreshMedia() {
        val c = media
        val t = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val a = c?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        if (c != null && t != null) {
            musicLabel.text = "♪ " + t + (if (a != null) " – $a" else "")
            musicLabel.visibility = View.VISIBLE
            playBtn.text = if (c.playbackState?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
        } else musicLabel.visibility = View.GONE
        applyState()
    }

    fun setMedia(c: MediaController?) {
        handler.post {
            media?.unregisterCallback(mediaCb)
            media = c
            c?.registerCallback(mediaCb)
            refreshMedia()
        }
    }

    fun post(t: String, b: String) = handler.post {
        title.text = t; body.text = b; setExpanded(true)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onDestroy() {
        instance = null
        media?.unregisterCallback(mediaCb)
        runCatching { wm.removeView(pill) }
        super.onDestroy()
    }

    companion object {
        var instance: IslandService? = null
        private var pendingMedia: MediaController? = null
        fun show(t: String, b: String) { instance?.post(t, b) }
        fun setMedia(c: MediaController?) { pendingMedia = c; instance?.setMedia(c) }
    }
}
